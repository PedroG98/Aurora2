import matplotlib.pyplot as plt 
import numpy as np
import pandas as pd
from mpl_toolkits.mplot3d import axes3d

data2 = pd.read_csv("trajectory2.dat", names=['t', 'x'], sep="\t")

plt.figure()
plt.plot(data2['t'], data2['x'], "b-", lw=0.7)
plt.xlabel("t")
plt.ylabel("x")
plt.savefig("plot2.png", dpi=150)


data1 = pd.read_csv("trajectory1.dat", names=['x', 'y', 'z'], sep="\t", usecols=[0,1,2])

fig = plt.figure()
ax = fig.add_subplot(projection='3d')
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_zlabel("z")
ax.plot(data1['x'], data1['y'], data1['z'], "b-", lw=0.7)
plt.savefig("plot1.png", dpi=150)

plt.show()
