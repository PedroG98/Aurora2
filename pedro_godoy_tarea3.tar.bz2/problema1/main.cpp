#include <iostream>
#include <fstream>
#include "NumericalIntegrator.h"
#include "Vector.h"


// Constantes para las EDOs
constexpr double a = 10;
constexpr double c = 8.0 / 3;
constexpr double rho = 28;

constexpr double mu = 0.01;


// Toma vector de la forma (x, y, z) y retorna (x', y', z')
Vector<double> lorentzAttractor(const Vector<double>& r)
{
    double xprime = a * (r[1] - r[0]);
    double yprime = r[0] * (rho - r[2]) - r[1];
    double zprime = r[0] * r[1] - c * r[2];
    return Vector<double>(std::vector<double>{xprime, yprime, zprime});
}

/* La 2da ecuación se puede transformar en un sistema (x,y) donde y = x'
El sistema viene determinado por:
    x' = y
    y' = mu(1 - x^2)y - x
*/
Vector<double> vanDerPol(const Vector<double>& r)
{
    double xprime = r[1];
    double yprime = mu * (1 - r[0]*r[0]) * r[1] - r[0];
    return Vector<double>(std::vector<double>{xprime, yprime});
}




int main()
{
    // Variables globales y archivos de escritura
    double t = 0.0;
    double stepsize = 0.01;
    std::ofstream file1("trajectory1.dat");
    std::ofstream file2("trajectory2.dat");

    // Ecuación 1
    // Posición inicial: (1, 1, 1)
    Vector<double> r{1.0, 1.0, 1.0};
    file1 << r << std::endl;

    // Simular por rk4 hasta t = 250
    while (t < 250.0)
    {
        r = rk4Step(lorentzAttractor, r, stepsize);
        t += stepsize;
        file1 << r << std::endl;
    }
    file1.close();

    // Ecuación 2
    // Estado inicial: Posición 1, velocidad 0
    t = 0.0;
    r = Vector<double>{1.0, 0.0};
    file2 << 0.0 << '\t' << r[0] << std::endl;

    // Se simula por rk4 hasta t = 250
    while (t < 250.0)
    {
        r = rk4Step(vanDerPol, r, stepsize);
        t += stepsize;
        // Interesa la posición vs el tiempo, la velocidad se ignora
        file2 << t << '\t' << r[0] << std::endl;
    }
    file2.close();
    
    // Los archivos se grafican con el script plot.py adjunto
    return 0;
}
