/* Esquemas de integración numéricos
 * Consisten en funciones que reciben el valor actual y devuelven el siguiente paso
 */
#ifndef NUMERICALINTEGRATOR_H
#define NUMERICALINTEGRATOR_H

#include "Vector.h"
#include <utility>      // Para std::pair


// Integrador rk4 para una EDO de la forma x' = F(x) (autónoma)
Vector<double> rk4Step(Vector<double> (*F)(const Vector<double>&), const Vector<double>& xn, double dt);
// Incluyendo dependencia temporal
Vector<double> rk4Step(Vector<double> (*F)(const Vector<double>&, const double), const Vector<double>& xn, double t, double dt);

// Integrador Verlet para una EDO de 2do orden de la forma x'' = a(x, t). Retorna par <posicion, velocidad>
// Position Verlet, conociendo las dos posiciones previas, el tiempo actual y el time-step dt. Retorna nueva posición y velocidad actual
std::pair<Vector<double>, Vector<double>> verletStep(Vector<double> (*a)(const Vector<double>&, const double),
                                                     const Vector<double>& xn1, const Vector<double>& xn0, double t, double dt);
// Velocity Verlet, conociendo posicion y velocidad previas. Retorna nueva posición y velocidad
std::pair<Vector<double>, Vector<double>> velVerletStep(Vector<double> (*a)(const Vector<double>&, const double),
                                                        const Vector<double>& xn, const Vector<double>& vn, double t, double dt);



#endif // NUMERICALINTEGRATOR_H
