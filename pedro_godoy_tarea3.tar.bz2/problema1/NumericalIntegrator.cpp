#include "NumericalIntegrator.h"

Vector<double> rk4Step(Vector<double> (*F)(const Vector<double>&), const Vector<double>& xn, double dt)
{
    // El componente explícito temporal desaparece
    Vector<double> k1 = F(xn);
    Vector<double> k2 = F(xn + k1 * dt/2.0);
    Vector<double> k3 = F(xn + k2 * dt/2.0);
    Vector<double> k4 = F(xn + k3 * dt);

    return xn + dt / 6 * (k1 + 2.0*k2 + 2.0*k3 + k4);
}



Vector<double> rk4Step(Vector<double> (*F)(const Vector<double>&, const double), const Vector<double>& xn, double t, double dt)
{
    // Versión con dependencia temporal
    Vector<double> k1 = F(xn               , t);
    Vector<double> k2 = F(xn + k1 * dt/2.0 , t + dt/2.0);
    Vector<double> k3 = F(xn + k2 * dt/2.0 , t + dt/2.0);
    Vector<double> k4 = F(xn + k3 * dt     , t + dt);

    return xn + dt / 6 * (k1 + 2.0*k2 + 2.0*k3 + k4);
}



std::pair<Vector<double>, Vector<double>> verletStep(Vector<double> (*a)(const Vector<double>&, const double),
                                                     const Vector<double>& xn1, const Vector<double>& xn0, double t, double dt)
{
    Vector<double> xn2 = 2.0*xn1 - xn0 + a(xn1, t) * dt*dt;
    Vector<double> vn1 = (xn2 - xn0) / (2 * dt);
    return std::make_pair(xn2, vn1);
}


std::pair<Vector<double>, Vector<double>> velVerletStep(Vector<double> (*a)(const Vector<double>&, const double),
                                                        const Vector<double>& xn, const Vector<double>& vn, double t, double dt)
{
    Vector<double> xn1 = xn + vn*dt + a(xn, t)*dt*dt/2.0;
    Vector<double> vn1 = vn + dt/2 * (a(xn, t) + a(xn1, t + dt));   // dt/2 (a(n) + a(n+1))
    return std::make_pair(xn1, vn1);
}
