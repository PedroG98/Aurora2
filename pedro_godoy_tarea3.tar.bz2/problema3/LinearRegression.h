/* El objeto modelo representa un prototipo para el comportamiento de un conjunto de datos
 * Está compuesto de una lista de funciones Y = {Yi}, tal que toda observación (xi,yi)
 * debe cumplir con suma_i ai Yi(xi) = yi, siendo ai una lista de parámetros a determinar, para encontrar el mejor ajuste posible
 */
#ifndef LINEARREGRESSION_H
#define LINEARREGRESSION_H

#include "Matrix.h"
#include <vector>
#include <utility>  // Para std::pair


// Nombre para pointer a función
using function = double (*)(double);


class Model
{
    private:
        // Funciones del modelo
        std::vector<function> Y;

    public:
        // Constructor genérico, tomando una lista de funciones modelo
        Model(const std::vector<function>& model_functions);

        // Realiza regresión lineal sobre el conjunto de observaciones (x, y+dy)
        // Retorna un par de vectores de la forma (parametros, errores)
        std::pair<std::vector<double>, std::vector<double>> linearRegression(const std::vector<double>& x,
                                                                             const std::vector<double>& y,
                                                                             const std::vector<double>& dy) const;
};






#endif // LINEARREGRESSION_H
