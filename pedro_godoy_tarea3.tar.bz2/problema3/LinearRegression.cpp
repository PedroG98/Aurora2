#include "LinearRegression.h"
#include <stdexcept>
#include <cmath>
#include <utility>  // std::pair

using namespace std;


// Constructor
Model::Model(const vector<function>& model_functions) :
    Y(model_functions)
{}


// Regresión lineal
pair<vector<double>, vector<double>> Model::linearRegression(const vector<double>& x,
                                                             const vector<double>& y,
                                                             const vector<double>& dy) const
{
    // Revisa que x, y, dy tengan igual tamaño
    if (x.size() != y.size() || y.size() != dy.size())
        throw std::invalid_argument("Dimensiones de datos no son consistentes");

    // Definición de las matrices A y b (Revisar apuntes de la clase)
    unsigned int N = x.size(),
                 M = Y.size();
    Matrix<double> A(N, M);
    Vector<double> b(N);
    for (unsigned int i = 0; i < N; i++)
    {
        for (unsigned int j = 0; j < M; j++)
            A(i, j) = Y[j](x[i]) / dy[i];
        b[i] = y[i] / dy[i];
    }

    // Para evitar repetir cálculos
    Matrix<double> AtAinverse = (A.transposed() * A).inverse();

    // Vector de parámetros
    Vector<double> a = AtAinverse * A.transposed() * b;
    std::vector<double> params;
    for (unsigned int i = 0; i < M; i++)
        params.push_back(a[i]);

    // AtAinverse es igual a la matriz de covarianza
    // Las raices de los elementos diagonales entregan los errores
    std::vector<double> errors;
    for (unsigned int i = 0; i < M; i++)
        errors.push_back(std::sqrt(AtAinverse(i, i)));

    // Retorna par de vectores <parámetros, errores>
    return std::make_pair(params, errors);
}
