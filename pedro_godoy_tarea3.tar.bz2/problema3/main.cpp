#include "LinearRegression.h"

#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>


// Funciones para el ajuste lineal (Polinómicas)
double constant(double x)
{
    return 1;
}

double linear(double x)
{
    return x;
}

double quadratic(double x)
{
    return x*x;
}

double cubic(double x)
{
    return x*x*x;
}


int main()
{
    // Lectura de datos
    std::ifstream trajectory_data("trajectory.dat");
    double t, y, dy;
    std::vector<double> T, Y, DY;
    while (trajectory_data >> t >> y >> dy)
    {
        T.push_back(t);
        Y.push_back(y);
        DY.push_back(dy);
    }

    // Modelo con las funciones polinómicas definidas arriba
    Model freefall(std::vector<function>{constant, linear, quadratic, cubic});

    // Se obtienen los parámetros de regresión lineal
    // auto es sintaxis de C++11, que permite determinar el tipo de una variable en tiempo de compilación
    // Evita tener que explicitar tipos largos, como este par de vectors
    auto params = freefall.linearRegression(T, Y, DY);

    // Los resultados esperados para los parámetros son 0, 0.95, 4.9, 0.5 (README.tex)
    // Se imprimen los valores teóricos y obtenidos por regresión en consola
    std::cout << "y_0   - Valor esperado:\t0\tValor experimental: " << params.first[0] << " +- " << params.second[0] << std::endl;
    std::cout << "vy_0  - Valor esperado:\t0.95\tValor experimental: " << params.first[1] << " +- " << params.second[1] << std::endl;
    std::cout << "g/2   - Valor esperado:\t4.9\tValor experimental: " << params.first[2] << " +- " << params.second[2] << std::endl;
    std::cout << "alpha - Valor esperado:\t0.5\tValor experimental: " << params.first[3] << " +- " << params.second[3] << std::endl;

    return 0;
}
