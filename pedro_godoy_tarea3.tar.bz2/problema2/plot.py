import numpy as np 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import pandas as pd


# Sin dato extra
splinedata = pd.read_csv("splineData.dat", names=["t", "x", "y", "z"], sep=" ")
naturaldata = pd.read_csv("splinePlotNaturalwoExtra.dat", names=["t", "x", "y", "z"], sep="\t")
periodicdata = pd.read_csv("splinePlotPeriodicwoExtra.dat", names=["t", "x", "y", "z"], sep="\t")


for coord in ["x", "y", "z"]:
	plt.figure()
	plt.plot(splinedata["t"], splinedata[coord], "rx", label="Datos")
	plt.plot(naturaldata["t"], naturaldata[coord], "b-", label="Spline")
	plt.xlabel("t")
	plt.ylabel(coord)
	plt.legend()
	plt.savefig(f"WithoutExtra/{coord}Natural.png", dpi=150)

	plt.figure()
	plt.plot(splinedata["t"], splinedata[coord], "rx", label="Datos")
	plt.plot(periodicdata["t"], periodicdata[coord], "b-", label="Spline")
	plt.xlabel("t")
	plt.ylabel(coord)
	plt.legend()
	plt.savefig(f"WithoutExtra/{coord}Periodic.png", dpi=150)

# Con dato extra
extra = splinedata.iloc[0].copy()
extra["t"] = splinedata["t"].iloc[-1] +  splinedata.t[1] - splinedata.t[0]
splinedata.loc[len(splinedata.index)] = extra

naturaldata = pd.read_csv("splinePlotNaturalwExtra.dat", names=["t", "x", "y", "z"], sep="\t")
periodicdata = pd.read_csv("splinePlotPeriodicwExtra.dat", names=["t", "x", "y", "z"], sep="\t")

for coord in ["x", "y", "z"]:
	plt.figure()
	plt.plot(splinedata["t"], splinedata[coord], "rx", label="Datos")
	plt.plot(naturaldata["t"], naturaldata[coord], "b-", label="Spline")
	plt.xlabel("t")
	plt.ylabel(coord)
	plt.legend()
	plt.savefig(f"WithExtra/{coord}Natural.png", dpi=150)

	plt.figure()
	plt.plot(splinedata["t"], splinedata[coord], "rx", label="Datos")
	plt.plot(periodicdata["t"], periodicdata[coord], "b-", label="Spline")
	plt.xlabel("t")
	plt.ylabel(coord)
	plt.legend()
	plt.savefig(f"WithExtra/{coord}Periodic.png", dpi=150)