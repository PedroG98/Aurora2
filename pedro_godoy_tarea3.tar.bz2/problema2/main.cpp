#include <iostream>
#include <fstream>
#include <vector>
#include "CubicSpline.h"


/* NOTA IMPORTANTE:
La tabla de datos proporcionada no es periódica, en el sentido de que el primer y último dato son distintos.
Para forzar periodicidad sobre los datos se puede agregar el dato inicial (x,y,z) al final de la lista. Sin embargo,
no hay forma de determinar el tiempo t asociado a este dato extra.
En este caso particular, se observó que la diferencia temporal entre cada par de datos consecutivos es exactamente 0.54,
por lo cual se le asigna el tiempo correspondiente a esta diferencia al dato adicional.

Por completitud, se crean los splines naturales y periódicos sin y con el dato extra, pero el spline periódico es válido
sólo en el 2do caso, como se observa en el gráfico WithoutExtra/xPeriodic.png (Se pierde la continuidad de la derivada)
*/

int main()
{
    // Lectura de datos
    std::ifstream splineData("splineData.dat");
    std::vector<double> ts, xs, ys, zs;
    double t, x, y, z;
    while (splineData >> t >> x >> y >> z)
    {
        ts.push_back(t);
        xs.push_back(x);
        ys.push_back(y);
        zs.push_back(z);
    }
    splineData.close();

    // Sin dato extra
    // Splines naturales
    CubicSpline XsplineN(ts, xs, false);
    CubicSpline YsplineN(ts, ys, false);
    CubicSpline ZsplineN(ts, zs, false);

    // Datos para graficar
    std::ofstream plotDataN("splinePlotNaturalwoExtra.dat");
    double trange = ts.back() - ts.front();
    for (double t = ts.front(); t < ts.back(); t += trange / 1000)
        plotDataN << t << '\t' << XsplineN(t) << '\t' << YsplineN(t) << '\t' << ZsplineN(t) << std::endl;

    plotDataN.close();

    // Splines periódicos
    CubicSpline XsplineP(ts, xs, true);
    CubicSpline YsplineP(ts, ys, true);
    CubicSpline ZsplineP(ts, zs, true);

    // Datos para graficar
    std::ofstream plotDataP("splinePlotPeriodicwoExtra.dat");
    trange = ts.back() - ts.front();
    for (double t = ts.front(); t < ts.back(); t += trange / 1000)
        plotDataP << t << '\t' << XsplineP(t) << '\t' << YsplineP(t) << '\t' << ZsplineP(t) << std::endl;

    plotDataP.close();


    // Con dato extra
    // t_n+1 = t_n + dt, con dt = t1 - t0
    ts.push_back(ts.back() + ts[1] - ts[0]);    
    xs.push_back(xs.front());
    ys.push_back(ys.front());
    zs.push_back(zs.front());

    // Splines naturales
    CubicSpline XsplineNE(ts, xs, false);
    CubicSpline YsplineNE(ts, ys, false);
    CubicSpline ZsplineNE(ts, zs, false);

    // Datos para graficar
    std::ofstream plotDataNE("splinePlotNaturalwExtra.dat");
    trange = ts.back() - ts.front();
    for (double t = ts.front(); t < ts.back(); t += trange / 1000)
        plotDataNE << t << '\t' << XsplineNE(t) << '\t' << YsplineNE(t) << '\t' << ZsplineNE(t) << std::endl;

    plotDataN.close();

    // Splines periódicos
    CubicSpline XsplinePE(ts, xs, true);
    CubicSpline YsplinePE(ts, ys, true);
    CubicSpline ZsplinePE(ts, zs, true);

    // Datos para graficar
    std::ofstream plotDataPE("splinePlotPeriodicwExtra.dat");
    trange = ts.back() - ts.front();
    for (double t = ts.front(); t < ts.back(); t += trange / 1000)
        plotDataPE << t << '\t' << XsplinePE(t) << '\t' << YsplinePE(t) << '\t' << ZsplinePE(t) << std::endl;

    plotDataP.close();

    return 0;
}
