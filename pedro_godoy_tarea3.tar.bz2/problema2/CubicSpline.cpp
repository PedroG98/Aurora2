﻿#include "CubicSpline.h"

#include <stdexcept>
#include "Matrix.h"
#include "LinearSystem.h"
#include <cmath>


// Los cálculos de A,B,M se realizan al construir el objeto spline
CubicSpline::CubicSpline(const std::vector<double>& xs, const std::vector<double>& ys, bool periodic) : N(xs.size()), X(xs), Y(ys)
{
    // Revisar que xs y ys sean compatibles (igual tamaño)
    if (xs.size() != ys.size())
        throw std::invalid_argument("Lista de puntos de dimensión incorrecta");

    // H = Distancias entre xs
    for (unsigned int i = 1; i < N; i++)
        H.push_back(xs[i] - xs[i - 1]);

    // Resolver y encontrar parámetros M
    if (periodic)
        solvePeriodic();
    else
        solveNatural();


    // A partir de los M se encuentran A, B (Revisar notas de curso)
    for (unsigned int i = 0; i < N - 1; i++)
    {
        A.push_back(Y[i] - M[i]*H[i]*H[i] / 6);
        B.push_back((Y[i + 1] - Y[i]) / H[i] + H[i]*(M[i] - M[i+1]) / 6);
    }
}


// Condición de borde natural
void CubicSpline::solveNatural()
{
    // Sin curvatura en extremos
    M = std::vector<double>(N);
    M[0] = 0.0;
    M[N - 1] = 0.0;

    // Matriz tridiagonal a ser resuelta (Revisar apuntes de curso). Rellenada con 0.0
    Matrix<double> T(N-2, N-2, 0.0);
    T(0, 0) = 2*(H[0] + H[1]);
    for (unsigned int i = 1; i < N - 2; i++)
    {
        T(i, i)     = 2*(H[i] + H[i+1]);    // b_i
        T(i, i - 1) = H[i];                 // a_i
        T(i - 1, i) = H[i];                 // c_i-1
    }

    // Vector r
    Vector<double> R(N - 2);
    for (unsigned int i = 0; i < N - 2; i++)
        R[i] = -6 * (Y[i + 1] - Y[i]) / H[i] - 6 * (Y[i + 1] - Y[i + 2]) / H[i + 1];

    // Se encuentran los M mediante el algoritmo de thomas y se escriben en el vector M
    Vector<double> ms = solveThomas(T, R);
    for (unsigned int i = 0; i < N - 2; i++)
        M[i + 1] = ms[i];
}


// Condición de borde: Periódica
void CubicSpline::solvePeriodic()
{
    // Vectores a, b, c, r
    std::vector<double> a, b, c;
    Vector<double> R(N, 1);

    // Se asume que el último dato es igual al primero, entonces la periodicidad es N-1
    // Para evitar violaciones de segmento se definen im1 ("i minus 1") / ip1 ("i plus 1") con período N-1
    for (int k = 0; k < N; k++)
    {
        int im1  = (N + k - 2) % (N-1), // Se le suma N-1 para evitar problemas con valores negativos
                                        // Entonces, k - 1 + N - 1 = k + N - 2
            i    = k % (N-1),
            ip1  = (k + 1) % (N-1);
        a.push_back(H[im1]);
        b.push_back(2*(H[im1] + H[i]));
        c.push_back(H[i]);
        R[k] = -6 * (Y[i] - Y[im1]) / H[im1] - 6 * (Y[i] - Y[ip1]) / H[i];
    }

    // Solución por algoritmo de Sherman-Morrison
    // BB = AA + u(vt)
    // Definicion de la matriz A (=AA)
    Matrix<double> AA(N, N, 0.0);
    AA(0, 0) = b[0] - a[0];
    for (unsigned int i = 1; i < N; i++)
    {
        AA(i, i) = b[i];
        AA(i - 1, i) = c[i - 1];
        AA(i, i - 1) = a[i];
    }
    AA(N-1, N-1) = b[N-1] - c[N-1];

    // Defincicion de u,v
    Vector<double> u(N, 0.0), v(N, 0.0);
    u[0] = a[0];
    u[N - 1] = c[N - 1];
    v[0] = 1.0;
    v[N - 1] = 1.0;

    // Definicion de z, y, zvt
    Matrix<double> Ainv = AA.inverse();     // Evita repetir cálculos
    Vector<double> z = Ainv * u;
    Vector<double> y = Ainv * R;

    Matrix<double> zvt(N, N, 0.0);
    for (unsigned int i = 0; i < N; i++)
        for (unsigned int j = 0; j < N; j++)
            zvt(i, j) = z[i] * v[j];

    // Solucion al sistema para x = MM (Revisar apuntes de clase)
    // En particular, vtz = dot(v, z)
    Vector<double> MM = (Identity<double>(N) - zvt / (1.0 + dot(v, z))) * y;
    for (unsigned int i = 0; i < N; i++)
        M.push_back(MM[i]);
}



// Retornar valor y de spline en x
double CubicSpline::operator()(const double x)
{
    // Sólo posible dentro del rango de los datos
    if (x < X[0] || x > X.back())
        throw std::domain_error("Spline sólo existe dentro del rango de los datos ingresados");

    // Encontrar índice de partición
    unsigned int index = 0;
    // Itera aumentando el índice hasta que X[index] sobrepasa a x
    while (x > X[++index]) {}
    // El índice buscado es el anterior al sobrepaso
    index--;

    // Fórmula de spline, revisar apuntes de la clase
    double dx = x - X[index];
    return A[index] + B[index] * dx + M[index + 1] * pow(dx, 3.0) / (6 * H[index]) - M[index] * pow(x - X[index + 1], 3.0)  / (6 * H[index]);
}
