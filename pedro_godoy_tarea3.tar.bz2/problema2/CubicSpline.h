/* Genera un spline cúbico entre dos variables x,y dado un conjunto de datos {(xi,yi)}
 */
#ifndef CUBICSPLINE_H
#define CUBICSPLINE_H

#include <vector>


class CubicSpline
{
    private:
        // Spline tiene la forma y(x) = A + Bx + Mi+1(x-xi)^3/6h - Mi(x-xi+1)^3/6h
        // (Nótese que se intercambiaron A<->B relativo a los apuntes de la clase)
        // Variables para determinar valor de spline    // Dados N puntos, cantidad de datos para cada vector
        std::vector<double> A;  // N-1
        std::vector<double> B;  // N-1
        std::vector<double> H;  // N-1
        std::vector<double> M;  // N

        // Datos de entrada
        unsigned int N;
        std::vector<double> X;  // N
        std::vector<double> Y;  // N

        // Métodos internos para resolver el sistema, para distintas condiciones de borde
        void solveNatural();        // Natural
        void solvePeriodic();       // Periódica

    public:
        CubicSpline(const std::vector<double>& xs, const std::vector<double>& ys, bool periodic);

        // Retornar valor y(x) de spline en x
        double operator()(const double x);
};

#endif // CUBICSPLINE_H
