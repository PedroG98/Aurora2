/* Implementación de algunos algoritmos para resolver sistemas lineales
 * Se resuelve el sistema Ax = b para x
 * NOTA: Por ahora sólo incluye el algoritmo de Thomas
 */
#ifndef LINEARSYSTEM_H
#define LINEARSYSTEM_H

#include "Matrix.h"
#include <cmath>


// Algortimo de thomas para A tridiagonal
template <class T>
Vector<T> solveThomas(const Matrix<T> A, const Vector<T> b);



// Definiciones -----------------------------------------------
// Argumentos por copia pues se realizan muchas operaciones sobre A, y se modifican las matrices
template <class T>
Vector<T> solveThomas(Matrix<T> A, Vector<T> b)
{
    // Asegurar que las dimenisiones sean correctas
    if (A.n() != A.m() || A.m() != b.length())
        throw std::domain_error("Parámetros dados no corresponden a un sistema lineal");

    // Asegurar que la matriz sea tridiagonal -> Fuera de las 3 diagonales todo es cero
    int N = A.n();
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
    {
            // Se está dentro de las 3 diagonales principales cuando |i - j| < 2
            if (abs(i - j) >= 2 && A(i, j) != T(0))
                throw std::domain_error("A no es tridiagonal");
    }

    // Paso 1: Eliminación gaussiana sobre fila inferior
    for (int i = 0; i < N - 1; i++)
    {
        T factor = A(i + 1, i) / A(i, i);
        A[i+1] -= A[i] * factor;
        b[i+1] -= b[i] * factor;
    }

    // Paso 2: Normalizacion
    for (int i = 0; i < N; i++)
    {
        T factor = A(i, i);
        A[i] /= factor;
        b[i] /= factor;
    }

    // Paso 3: Sustitución hacia arriba
    Vector<T> x(N, 1);
    x[N - 1] = b[N - 1];
    for (int i = N - 2; i >= 0; i--)   // Contador desde N-1 hasta 0
        x[i] = b[i] - A(i, i + 1) * x[i + 1];

    return x;
}


#endif // LINEARSYSTEM_H
