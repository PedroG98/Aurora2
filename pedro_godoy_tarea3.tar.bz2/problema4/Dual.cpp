#include "Dual.h"

#include <cmath>


// Constructores ---------------------------------------------
// Por defecto
Dual::Dual(unsigned int N)
{
    F = 0;
    DF = Vector<double>(N, 1.0);
    HF = Matrix<double>(N, N, 0.0);
}

// Con valor y derivada
Dual::Dual(double F, const Vector<double>& DF) :
    N(DF.length()), F(F), DF(DF), HF(Matrix<double>(N, N, 0.0))
{}

// Genérico
Dual::Dual(double F, const Vector<double>& DF, const Matrix<double>& HF) :
    N(DF.length()), F(F), DF(DF), HF(HF)
{}


// Por copia
Dual::Dual(const Dual& other) :
    N(other.N), F(other.F), DF(other.DF), HF(other.HF)
{}


// Operadores ----------------------------------------
// Asignación
Dual Dual::operator=(const Dual& other)
{
    // Profunda
    if (this != &other)
    {
        N = other.N;
        F = other.F;
        DF = other.DF;
        HF = other.HF;
    }
    return *this;
}

// Getters
unsigned int Dual::Nvars() const
{
    return N;
}

double Dual::val() const
{
    return F;
}
// Derivada i
double Dual::partial(unsigned int i) const
{
    return DF[i];
}
// 2da derivada i,j
double Dual::partial2(unsigned int i, unsigned int j) const
{
    return HF(i, j);
}

Vector<double> Dual::Jacobian() const
{
    return DF;
}

Matrix<double> Dual::Hessian() const
{
    return HF;
}



// Suma por componentes, por linealidad del operador derivada
Dual Dual::operator+(const Dual &other) const
{
    return Dual(F + other.F, DF + other.DF, HF + other.HF);
}

// Idem
Dual Dual::operator-(const Dual &other) const
{
    return Dual(F - other.F, DF - other.DF, HF - other.HF);
}

// Propagación de derivadas parciales utilizando álgebra lineal
Dual Dual::operator*(const Dual &other) const
{
    // 1ra derivada: DFG = FDG + GDF
    Vector<double> DFG = F * other.DF + other.F * DF;

    // 2da derivada: D^2(FG) = D(DFG) = FD^2G + DFDG + DGDF + GD^2F
    Matrix<double> HFG = F * other.HF + other.F * HF;
    for (unsigned int i = 0; i < N; i++)
        for (unsigned int j = 0; j < N; j++)
        {
            // Productos exteriores DFDG, DGDF
            HFG(i, j) += DF[i] * other.DF[j];
            HFG(j, i) += DF[i] * other.DF[j];
        }

    return Dual(F * other.F, DFG, HFG);
}


// Operaciones con constantes
// Suma sólo modifica valor
Dual Dual::operator+(double x) const
{
    return Dual(F + x, DF, HF);
}

// Multiplicacion se aplica a todas las derivadas de todo orden
Dual Dual::operator*(double x) const
{
    return Dual(x*F, x*DF, x*HF);
}


// Operadores externos ------------------------------
std::ostream& operator <<(std::ostream& os, const Dual &d)
{
    // Entrega las derivadas asociadas a cada componente
    os << d.val();
    for (unsigned int i = 0; i < d.Nvars(); i++)
        os << " + " << d.partial(i) << "e" << i;
    for (unsigned int i = 0; i < d.Nvars(); i++)
        for (unsigned int j = 0; j < d.Nvars(); j++)
        {
            os << " + " << d.partial2(i, j) << "e" << i << "e" << j;
        }
    os << std::endl;
    return os;
}

// Callbacks para permitir operaciones por la izquierda
Dual operator+(const double x, const Dual& d)
{
    return d + x;
}
Dual operator*(const double x, const Dual& d)
{
    return d * x;
}