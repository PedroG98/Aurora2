#include <iostream>

#include "RootFinder.h"
#include "Dual.h"


// Función f a la cual se le busca el mínimo
// Toma los argumentos r=(x,y,z) y devuelve un número dual (extendido)
Dual f(const Vector<double>& r)
{
    // Variables x, y, z
    Dual x(r[0], {1.0, 0.0, 0.0});
    Dual y(r[1], {0.0, 1.0, 0.0});
    Dual z(r[2], {0.0, 0.0, 1.0});
    // Propagación de número dual
    return (x*x - 4.0*x + 10.0)*(y*y - 4.0*y + 6.0)*(z*z - 3.0*z + 10.0);
}

/*
    NOTA:
    f es producto de cuadráticas con coeficiente principal positivo, por lo tanto la función está acotada por abajo, tiende a +infinito
    cuando se aleja del origen y es continua. Por lo tanto, tiene un mínimo global.
    Además, f es diferenciable, así que su mínimo global corresponde a un mínimo local.
    El objetivo es entonces buscar el extremo local más pequeño de f. Se corrobora que el punto corresponde a un mínimo observando 
    si su hessiana es definida positiva.
*/

int main()
{
    // Inicializando arbitrariamente en (0,0,0), se buscan extremos locales por el algoritmo de Newton, con valores iniciales en el rango
    // [-10,10]X[-10,10]X[-10,10] (de largo similar al valor de los coeficientes). En total se hacen 1331 búsquedas
    double minValue = f({0.0, 0.0, 0.0}).val();
    Vector<double> min;

    for (double x = -10.0; x <= 10.0; x += 2.0)
        for (double y = -10.0; y <= 10.0; y += 2.0)
            for (double z = -10.0; z <= 10.0; z += 2.0)
            {
                // Se encuentra el extremo con valor inicial (x,y,z) (Precisión 0.0001 arbitraria)
                Vector<double> extremum = findExtremum(f, {x, y, z}, 0.0001);
                // Si este punto entrega un valor menor a minValue, es el nuevo mínimo
                if (f(extremum).val() < minValue)
                {
                    min = extremum;
                    minValue = f(extremum).val();
                }
            }
            

    // Convenientemente, la hessiana del extremo encontrado (2, 2, 1.5) es diagonal con elementos positivos, entonces es definida positiva
    // y el punto encontrado es mínimo local -> mínimo global
    std::cout << "Mínimo:\t" << min << std::endl;
    std::cout << "Valor:\t" << f(min).val() << std::endl;
    std::cout << "Hessiana:\n" << f(min).Hessian() << std::endl;

    return 0;
}
