/*
    Clase para números Duales con un número arbitrario de argumentos y soporte de 2das derivadas
    Esencialmente utiliza las clases Vector y Matrix para guardar las 1ras y 2das derivadas (jacobiana y hessiana)
    No se implementan funciones especiales, sólo multiplicaciones, suma y resta
*/
#ifndef Dual_H
#define Dual_H

#include <iostream>
#include "Matrix.h"


// Clase dual extendida
class Dual
{
    private:
        // Cantidad de variables
        unsigned int N;
        // Valor
        double F;
        // 1ras derivadas (Jacobiana)
        Vector<double> DF;
        // 2das derivadas (Hessiana)
        Matrix<double> HF;

    public:
        // Por defecto (Número de variables dado)
        Dual(unsigned int N);
        // Con valor y derivada (hessiana 0)
        // Útil para inicializar funciones de la forma f(x1, x2, ..., xn) = xi
        Dual(double F, const Vector<double>& DF);
        // Genérico
        Dual(double F, const Vector<double>& DF, const Matrix<double>& HF);
        // Por copia
        Dual(const Dual& other);

        // Asignación
        Dual operator=(const Dual& other);

        // Getters (Setters no son necesarios, pues no interesa cambiar manualmente los valores de las derivadas)
        // Cantidad de variables
        unsigned int Nvars() const;
        // Valor
        double val() const;
        // Derivada parcial i
        double partial(unsigned int i) const;
        // 2da derivada parcial i,j
        double partial2(unsigned int i, unsigned int j) const;
        // Jacobiana y hessiana en forma matricial
        Vector<double> Jacobian() const;
        Matrix<double> Hessian() const;

        // Operadores aritméticos
        Dual operator+(const Dual &other) const;
        Dual operator-(const Dual &other) const;
        Dual operator*(const Dual &other) const;
        // Por constantes
        Dual operator+(double x) const;
        Dual operator*(double x) const;
};


// Operadores externos
// Extracción
std::ostream& operator <<(std::ostream& os, const Dual &d);
// Arimética con constantes
Dual operator+(double x, const Dual& d);
Dual operator*(double x, const Dual& d);


#endif
