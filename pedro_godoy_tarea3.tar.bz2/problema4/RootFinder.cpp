#include "RootFinder.h"

#include "Matrix.h"


// Algoritmo de Newton sobre Dphi
Vector<double> findExtremum(Dual (*phi)(const Vector<double>& r), const Vector<double>& initial_pos, double epsilon)
{
    Vector<double> r = initial_pos;
    Dual Dr = phi(r);

    do {
        // r = r - D(Dphi)-1 * Jphi donde Dphi es la función a minimizar (jacobiano de phi) 
        // D(Dphi) es el hessiano de phi
        r -= Dr.Hessian().inverse() * Dr.Jacobian();
        // Actualización del valor de Dphi
        Dr = phi(r);
    }
    // Hasta que Dphi tenga norma menor a epsilon
    while (Dr.Jacobian().norm() >= epsilon);

    return r;
}

