#ifndef ROOTFINDER_H
#define ROOTFINDER_H

#include "Vector.h"
#include "Dual.h"


// Newton sobre jacobiana
// Encuentra punto con Dphi = 0 -> Extremo local
Vector<double> findExtremum(Dual (*phi)(const Vector<double>& r), const Vector<double>& initial_pos, double epsilon);


#endif // ROOTFINDER_H
